import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Terminal extends Application {
    private TextArea outputArea;
    private TextField inputField;

    @Override
    public void start(Stage primaryStage) {
        outputArea = new TextArea();
        outputArea.setEditable(false);

        inputField = new TextField();
        inputField.setOnAction(event -> executeCommand(inputField.getText()));

        VBox root = new VBox(10, outputArea, inputField);
        Scene scene = new Scene(root, 600, 400);

        primaryStage.setTitle("Ubuntu Terminal Emulator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void executeCommand(String command) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder();
            processBuilder.command("bash", "-c", command);

            Process process = processBuilder.start();

            // Чтение стандартного потока вывода
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            StringBuilder output = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Чтение ошибок
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            while ((line = errorReader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Выводим результат в TextArea
            outputArea.appendText("> " + command + "\n" + output.toString() + "\n");

            // Очистка поля ввода
            inputField.clear();
        } catch (Exception e) {
            outputArea.appendText("Ошибка выполнения команды: " + e.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
